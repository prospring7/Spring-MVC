package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Employee;
import com.cognizant.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private Validator validator;
	
	@RequestMapping(value="getEmployee.htm",method=RequestMethod.GET)
	public ModelAndView getAllEmployees(){
		ModelAndView mv=new ModelAndView();
		List<Employee> empList=employeeService.getAllEmployees();
		mv.addObject("empList",empList);
		mv.setViewName("empdetails");
		return mv;
		
	}
	@RequestMapping(value="registerEmployee.htm",method=RequestMethod.GET)
	public String loadForm(){
		
		return "empform";
		
	}
	@ModelAttribute("employee")
public Employee loadEmployee(){
	
	Employee employee=new Employee();
	employee.setEmpId(0);
	employee.setEmpName("Please type full name");
	employee.setEmpSalary(25000);
	return employee;
	
}	
	@ModelAttribute("designationList")
	public List<String> getDesignationNames(){
		
		return employeeService.getDesignationNames();
	}

	
	@RequestMapping(value="registerprocess.htm",method=RequestMethod.POST)
	public ModelAndView registerProcess(@ModelAttribute("employee")Employee employee,Errors errors){
		ModelAndView mv=new ModelAndView();

		ValidationUtils.invokeValidator(validator, employee, errors);
		if(errors.hasErrors()){
			
			mv.setViewName("empform");

		}else{
		
		boolean persistResult=employeeService.persistEmployee(employee);
		if(persistResult){
			mv.addObject("status","Registered successfully");
			mv.setViewName("empform");
		}else{
			mv.addObject("status","Registration failed");
			mv.setViewName("empform");
		}
		}
	return mv;
		
	}
}
