package com.cognizant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.cognizant.entity.Designation;
@Component("DesignationsRowMapper")
public class DesignationsRowMapper implements RowMapper<Designation> {

	@Override
	public Designation mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		Designation designation=new Designation();
		designation.setDesignationId(arg0.getInt("designation_id"));
		designation.setDesignationName(arg0.getString("designation_name"));
		return designation;
	}

}
