package com.cognizant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
@Component("EmpIdRowMapper")
public class EmpIdRowMapper implements RowMapper<Integer> {

	@Override
	public Integer mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		Integer o=new Integer(arg0.getInt("emp_id"));
		
		return o;
	}

}
