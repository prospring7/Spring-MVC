package com.cognizant.dao;

import java.util.List;

import com.cognizant.entity.Employee;

public interface EmployeeDAO {
	
	List<Employee> getAllEmployees();
	List<String> getDesignationNames();
	boolean persistEmployee(Employee employee);
	List<Integer> getAllEmpIds();

}
