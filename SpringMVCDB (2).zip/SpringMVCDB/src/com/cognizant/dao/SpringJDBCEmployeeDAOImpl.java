package com.cognizant.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Designation;
import com.cognizant.entity.Employee;
import com.cognizant.helper.Query;

import java.util.List;

import com.cognizant.entity.Employee;

@Repository("springJDBCEmployeeDAOImpl")
public class SpringJDBCEmployeeDAOImpl  implements EmployeeDAO{
	
	@Autowired@Qualifier("EmployeeRowMapper")
	private RowMapper<Employee> mapper;
	
	@Autowired@Qualifier("DesignationsRowMapper")
	private RowMapper<Designation> designationMapper;
	@Autowired@Qualifier("EmpIdRowMapper")
	private RowMapper<Integer> empIdMapper;
	
	@Autowired
	private JdbcTemplate template;
	
	@Autowired
	private Query query;

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		
		return template.query(query.getSelectQuery(), mapper);
		
	}

	@Override
	public List<String> getDesignationNames() {
		// TODO Auto-generated method stub
		List<Designation> designationList=template.query(query.getSelectDesignationNames(), designationMapper);
		List<String> designationNamesList=new ArrayList<>();
		
for(Designation designation:designationList){
	designationNamesList.add(designation.getDesignationName());
}
		
		return designationNamesList;
	}

	@Override
	public boolean persistEmployee(Employee employee) {
		// TODO Auto-generated method stub
		int rows=template.update(query.getInsertQuery(), new Object[]{employee.getEmpId(),employee.getEmpName(),employee.getEmpSalary(),employee.getEmpDesignation()});
		if(rows>0)
			return true;
		else
		return false;
	}

	@Override
	public List<Integer> getAllEmpIds() {
		// TODO Auto-generated method stub
		return template.query(query.getFetchEmpIdQuery(),empIdMapper);
	}

}
