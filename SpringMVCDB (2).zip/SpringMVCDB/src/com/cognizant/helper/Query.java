package com.cognizant.helper;

public class Query {

	public Query(){}
	
	private String selectQuery;
	private String selectDesignationNames;
	private String insertQuery;
	private String fetchEmpIdQuery;
	
	
	
	
	
	

	public String getFetchEmpIdQuery() {
		return fetchEmpIdQuery;
	}

	public void setFetchEmpIdQuery(String fetchEmpIdQuery) {
		this.fetchEmpIdQuery = fetchEmpIdQuery;
	}

	public String getInsertQuery() {
		return insertQuery;
	}

	public void setInsertQuery(String insertQuery) {
		this.insertQuery = insertQuery;
	}

	public String getSelectDesignationNames() {
		return selectDesignationNames;
	}

	public void setSelectDesignationNames(String selectDesignationNames) {
		this.selectDesignationNames = selectDesignationNames;
	}

	public String getSelectQuery() {
		return selectQuery;
	}

	public void setSelectQuery(String selectQuery) {
		this.selectQuery = selectQuery;
	}
	
	
}
