package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.Employee;

public interface EmployeeService {
	List<Employee> getAllEmployees();
	List<String> getDesignationNames();
	boolean persistEmployee(Employee employee);
	List<Integer> getAllEmpIds();

}
