package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cognizant.dao.EmployeeDAO;
import com.cognizant.entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired@Qualifier("springJDBCEmployeeDAOImpl")
	private EmployeeDAO employeeDAO;

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmployees();
	}

	@Override
	public List<String> getDesignationNames() {
		// TODO Auto-generated method stub
		return employeeDAO.getDesignationNames();
	}

	@Override
	public boolean persistEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeDAO.persistEmployee(employee);
	}

	@Override
	public List<Integer> getAllEmpIds() {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmpIds();
	}
	
	

}
