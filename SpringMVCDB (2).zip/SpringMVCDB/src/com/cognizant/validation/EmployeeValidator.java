package com.cognizant.validation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cognizant.entity.Employee;
import com.cognizant.service.EmployeeService;

@Component
public class EmployeeValidator implements Validator {
	
	@Autowired
	private EmployeeService employeeService;
	

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return arg0.equals(Employee.class);
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		
		Employee employee=(Employee)arg0;
		List<Integer> empIds=employeeService.getAllEmpIds();
		for(int empId:empIds){
			
			if(empId==employee.getEmpId()){
				arg1.rejectValue("empId", "com.cognizant.entity.Employee.empId.duplicate");
			}
		}
		
		if(employee.getEmpSalary()<0){
			arg1.rejectValue("empSalary", "com.cognizant.entity.Employee.empSalary.negative");

		}
		
	}
	
	

}
