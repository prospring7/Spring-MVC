package com.cognizant.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Employee;
import com.cognizant.helper.Query;
import java.util.List;
import com.cognizant.entity.Employee;

@Repository("springJDBCEmployeeDAOImpl")
public class SpringJDBCEmployeeDAOImpl  implements EmployeeDAO{
	
	@Autowired
	private RowMapper<Employee> mapper;
	
	@Autowired
	private JdbcTemplate template;
	
	@Autowired
	private Query query;

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		
		return template.query(query.getSelectQuery(), mapper);
		
	}

}
