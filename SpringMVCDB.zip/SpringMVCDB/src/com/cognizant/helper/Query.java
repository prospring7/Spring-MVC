package com.cognizant.helper;

public class Query {

	public Query(){}
	
	private String selectQuery;

	public String getSelectQuery() {
		return selectQuery;
	}

	public void setSelectQuery(String selectQuery) {
		this.selectQuery = selectQuery;
	}
	
	
}
