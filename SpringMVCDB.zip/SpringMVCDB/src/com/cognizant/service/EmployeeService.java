package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.Employee;

public interface EmployeeService {
	List<Employee> getAllEmployees();

}
